# Expedition 33 T-shirt (add-on for Big Boss T-shirt v8, Gymfiend fit)

Install: copy `archive` and `r6` into the Cyberpunk 2077 folder. Requires ArchiveXL 1.5+ and TweakXL.
Get the item with CET: Game.AddToInventory("Items.E33_Tshirt", 1)

The Clair Obscur: Expedition 33 key art covers the whole shirt texture (front, back, sleeves).
Uses the Gymfiend-fit shirt mesh from Big Boss T-shirt v8 (copied into its own files, own item/factory/appearance IDs),
so it installs next to the Big Boss mod without overwriting anything. `print_preview.png` is the texture atlas.
